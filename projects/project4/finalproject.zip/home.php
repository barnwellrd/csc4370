<?php session_start();?>
<?php include 'header.php';?>
		<div id ="para">Fly with us<br>
			Whether it's your first flight or simply your latest, we work to anticipate your every need.
		</div>
		<div id ="clear1"></div>
	</body>
</html>